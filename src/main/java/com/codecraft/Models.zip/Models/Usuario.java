package com.codecraft.Models;

public class Usuario {
    
}
