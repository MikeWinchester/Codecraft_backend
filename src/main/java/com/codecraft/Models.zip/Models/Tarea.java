package com.codecraft.Models;

public class Tarea {
    
}
