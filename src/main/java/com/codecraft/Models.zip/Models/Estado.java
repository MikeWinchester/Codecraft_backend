package com.codecraft.Models;

public class Estado {
    
}
